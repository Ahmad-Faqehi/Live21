<?php

date_default_timezone_set("Asia/Riyadh");
setlocale(LC_ALL, 'ar_AE.utf8');
//echo "Time now:  ". date('Y-m-d', 1610571600) . "T".  date('H:i', 1610571600) ."\n";
//echo "Fot stop:  ". date('y-m-d H:i', 1610804580) . "\n";
include "404.html";



//$dayNow = date('l', time());
//$dateNow = date('Y-m-d', time());
//echo $dayTommoro = date('Y-m-d', strtotime( date('Y-m-d', time()) . " +1 days"));
//
//echo "The day today is: " . convertToArabic( $dayNow) . " and the day tommoro is " . convertToArabic($dayTommoro);

//echo time();
//die();

//echo strtotime("21-01-13 +1 day");


?>
