<?php
date_default_timezone_set("Asia/Riyadh");
include ("Db_Object.php");
include ("Ads.php");
include ("Links.php");
include ("Live.php");
include ("User.php");
include ("Equipe.php");
include ("ProLinks.php");


?>